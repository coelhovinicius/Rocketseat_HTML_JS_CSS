#HTML - Hypertext Modeling Language
<h1>Título</h1>
<a href="https://linkedin.com/in/coelhovinicius" target="_blank">LinkedIN</a>

'''js
// Criação de variável
const mensagem = "Bom te ver aqui! "
//Função alert
alert(mensagem + (10 * 100) + "abraços!")
// Bom te ver aqui! 1000 abraços!

'''

## Array - Vetores []
const perguntas = [

]

## Objetos {}
const celular = {
  marca: 'samsung',
  cor: 'preto',
  peso: 200
}
